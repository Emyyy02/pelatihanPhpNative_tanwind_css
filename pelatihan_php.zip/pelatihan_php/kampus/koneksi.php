<?php
$azmayz = mysqli_connect("localhost","root","","p_mahasiswa");
// if ($azmayz ==true) {
//     echo "berhasil terkoneksi";
// }else {
//     echo "gagal terkoneksi";
// }